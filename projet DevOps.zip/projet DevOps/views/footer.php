<footer>
    <p>&copy; 2024 ESP News by CMTT</p>
</footer>
</body>
</html>
