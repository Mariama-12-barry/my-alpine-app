<main>
    <p>Bienvenue sur ESP News. Sélectionnez une catégorie pour commencer.</p>
</main>
